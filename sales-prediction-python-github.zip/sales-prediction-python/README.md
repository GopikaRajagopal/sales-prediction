# Sales Prediction Using Python

An end-to-end beginner-friendly machine learning project that predicts product sales using advertising spend across TV, radio, and newspaper platforms, with an optional target-segment feature.

## Project objectives

- Predict sales using advertising expenditure.
- Clean and transform data before modelling.
- Select useful input features.
- Train and compare regression models.
- Measure model performance.
- Analyze how advertising spend relates to sales.
- Provide practical, data-based marketing insights.

## Project structure

```text
sales-prediction-python/
├── data/
│   ├── advertising_sales_sample.csv
│   └── README.md
├── models/
│   └── .gitkeep
├── outputs/
│   └── .gitkeep
├── sales_prediction.py
├── requirements.txt
├── .gitignore
└── README.md
```

## 1. Install and run

Recommended: Python 3.9 or newer.

```bash
git clone <your-repository-url>
cd sales-prediction-python
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

Run the project with the included demonstration dataset:

```bash
python sales_prediction.py
```

Use your own CSV dataset:

```bash
python sales_prediction.py --data path/to/your_dataset.csv
```

## 2. Dataset format

The included `data/advertising_sales_sample.csv` is a small synthetic demonstration dataset. It contains:

| Column | Description |
|---|---|
| TV | Advertising spend on TV |
| Radio | Advertising spend on radio |
| Newspaper | Advertising spend on newspaper |
| Target_Segment | Example customer segment |
| Sales | Sales outcome (target variable) |

The script also accepts common variations such as `sales`, `target`, `tv`, `radio`, `newspaper`, `social_media`, `platform`, and `target_segment`. If your dataset uses different column names, edit `COLUMN_ALIASES` near the top of `sales_prediction.py`.

**Important:** The image supplied for the assignment mentions a downloadable dataset but does not show the actual download URL or dataset file. Therefore, the CSV included here is synthetic sample data to make the project runnable. Replace it with the official assignment dataset before reporting final results.

## 3. Workflow

1. Load the CSV using Pandas.
2. Standardize column names and convert numeric values.
3. Handle missing values using median/mode imputation.
4. Encode categorical fields using one-hot encoding.
5. Scale numeric fields.
6. Use SelectKBest feature selection.
7. Train Linear Regression and Random Forest regression models.
8. Compare MAE, MSE, RMSE, and R² on a held-out test set.
9. Create charts showing actual vs predicted sales, advertising spend vs sales, and feature importance.
10. Save the best model and a text report.

## 4. Output files

After running the script:

- `models/sales_prediction_model.joblib` — fitted preprocessing, feature-selection and regression pipeline.
- `outputs/model_metrics.txt` — model evaluation scores.
- `outputs/actual_vs_predicted.png` — actual sales compared with predicted sales.
- `outputs/advertising_vs_sales.png` — advertising spend compared with sales.
- `outputs/feature_importance.png` — feature importance for the selected best model when supported.

## 5. Interpreting results

- **MAE:** Average absolute prediction error. Lower is better.
- **MSE:** Average squared prediction error. Lower is better.
- **RMSE:** Error in the same unit as the sales target. Lower is better.
- **R²:** Proportion of target variation explained by the model. Closer to 1 is generally better.

The script prints correlations and model metrics based on the data it actually loads. Do not assume that more advertising always causes more sales: this dataset can show association, not prove causation. Marketing decisions should also consider campaign quality, timing, audience, and profitability.

## Technologies

Python, Pandas, NumPy, Matplotlib, Seaborn, and Scikit-learn.
