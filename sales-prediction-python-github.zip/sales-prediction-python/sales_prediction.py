"""
Sales Prediction Using Python
Run: python sales_prediction.py
Custom data: python sales_prediction.py --data path/to/your_dataset.csv
"""

import argparse
import re
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent
DEFAULT_DATA = ROOT / "data" / "advertising_sales_sample.csv"
MODEL_DIR = ROOT / "models"
OUTPUT_DIR = ROOT / "outputs"

COLUMN_ALIASES = {
    "sales": ["sales", "sale", "revenue", "target", "units_sold"],
    "tv": ["tv", "tv_advertising", "tv_spend"],
    "radio": ["radio", "radio_advertising", "radio_spend"],
    "newspaper": ["newspaper", "newspaper_advertising", "newspaper_spend"],
    "social_media": ["social_media", "social media", "social_media_spend"],
    "target_segment": ["target_segment", "target segment", "segment", "customer_segment"],
    "platform": ["platform", "advertising_platform", "channel"],
    "date": ["date", "month", "week", "campaign_date"],
}


def clean_column_name(column):
    return re.sub(r"[^a-z0-9]+", "_", str(column).strip().lower()).strip("_")


def standardize_columns(df):
    df = df.copy()
    df.columns = [clean_column_name(c) for c in df.columns]
    aliases = {
        standard: {clean_column_name(alias) for alias in names}
        for standard, names in COLUMN_ALIASES.items()
    }
    rename_map = {}
    for standard, names in aliases.items():
        for existing in df.columns:
            if existing in names:
                rename_map[existing] = standard
                break
    return df.rename(columns=rename_map)


def prepare_data(raw_df):
    df = standardize_columns(raw_df)

    if "sales" not in df.columns:
        raise ValueError(
            "Target column not found. Rename the sales target column to 'sales' "
            "or add its name to COLUMN_ALIASES."
        )

    # Convert the target and known numeric advertising columns safely.
    for col in ["sales", "tv", "radio", "newspaper", "social_media"]:
        if col in df.columns:
            df[col] = pd.to_numeric(
                df[col].astype(str).str.replace(",", "", regex=False)
                .str.extract(r"([-+]?\d*\.?\d+)")[0],
                errors="coerce"
            )

    df = df.dropna(subset=["sales"]).copy()
    df = df[df["sales"] >= 0].copy()

    # Remove date-like columns for this regression baseline. A time-series
    # forecast would need date-aware ordering and validation instead.
    if "date" in df.columns:
        df = df.drop(columns=["date"])

    feature_columns = [
        col for col in df.columns
        if col != "sales" and not df[col].isna().all()
    ]
    if not feature_columns:
        raise ValueError("No usable feature columns were found.")

    X = df[feature_columns].copy()
    y = df["sales"].copy()

    for col in X.select_dtypes(include=["object", "string"]).columns:
        X[col] = X[col].astype("string").str.strip()
        X[col] = X[col].replace("", pd.NA)

    # Remove columns with only one non-missing unique value.
    useful_columns = [
        col for col in X.columns if X[col].nunique(dropna=True) > 1
    ]
    X = X[useful_columns]
    if X.empty:
        raise ValueError("All feature columns are constant or empty.")

    return X, y


def make_preprocessor(X):
    numeric_columns = X.select_dtypes(include=["number"]).columns.tolist()
    categorical_columns = [c for c in X.columns if c not in numeric_columns]

    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    return ColumnTransformer(transformers=[
        ("numeric", numeric_pipeline, numeric_columns),
        ("categorical", categorical_pipeline, categorical_columns),
    ])


def build_pipeline(X, estimator):
    preprocessor = make_preprocessor(X)
    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("feature_selection", SelectKBest(score_func=f_regression, k="all")),
        ("regressor", estimator),
    ])


def evaluate_model(name, model, X_test, y_test):
    predictions = model.predict(X_test)
    mse = mean_squared_error(y_test, predictions)
    return {
        "model": name,
        "MAE": mean_absolute_error(y_test, predictions),
        "MSE": mse,
        "RMSE": np.sqrt(mse),
        "R2": r2_score(y_test, predictions) if len(y_test) > 1 else float("nan"),
        "predictions": predictions,
    }


def plot_advertising_relationships(df):
    ad_columns = [c for c in ["tv", "radio", "newspaper", "social_media"] if c in df.columns]
    if not ad_columns:
        return

    plot_data = df[ad_columns + ["sales"]].copy()
    plot_data = plot_data.apply(pd.to_numeric, errors="coerce")
    long_data = plot_data.melt(
        id_vars="sales", var_name="advertising_channel", value_name="advertising_spend"
    ).dropna()

    plt.figure(figsize=(9, 6))
    sns.scatterplot(
        data=long_data, x="advertising_spend", y="sales",
        hue="advertising_channel", alpha=0.75
    )
    plt.title("Advertising Spend vs Sales")
    plt.xlabel("Advertising spend")
    plt.ylabel("Sales")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "advertising_vs_sales.png", dpi=150)
    plt.close()


def save_feature_importance(model, output_path):
    try:
        preprocessor = model.named_steps["preprocessor"]
        selector = model.named_steps["feature_selection"]
        estimator = model.named_steps["regressor"]
        names = preprocessor.get_feature_names_out()
        selected_names = names[selector.get_support()]

        if hasattr(estimator, "feature_importances_"):
            values = estimator.feature_importances_
        elif hasattr(estimator, "coef_"):
            values = np.abs(np.ravel(estimator.coef_))
        else:
            return

        importance = (
            pd.DataFrame({"feature": selected_names, "importance": values})
            .sort_values("importance", ascending=False)
            .head(15)
        )
        plt.figure(figsize=(9, 6))
        plt.barh(importance["feature"], importance["importance"])
        plt.gca().invert_yaxis()
        plt.title("Most Influential Model Features")
        plt.xlabel("Importance (or absolute coefficient)")
        plt.ylabel("Feature")
        plt.tight_layout()
        plt.savefig(output_path, dpi=150)
        plt.close()
    except (ValueError, AttributeError):
        print("Could not create feature-importance chart for this dataset.")


def main():
    parser = argparse.ArgumentParser(description="Predict sales using regression.")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA,
                        help="CSV dataset path.")
    args = parser.parse_args()

    if not args.data.exists():
        raise FileNotFoundError(f"Dataset not found: {args.data}")

    MODEL_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    raw_df = pd.read_csv(args.data)
    print("\nDataset preview:\n", raw_df.head())
    print("\nDataset shape:", raw_df.shape)
    print("\nMissing values:\n", raw_df.isnull().sum())

    standardized = standardize_columns(raw_df)
    if "sales" in standardized.columns:
        print("\nCorrelation with sales (numeric columns):")
        print(standardized.select_dtypes(include="number").corr()["sales"].sort_values(ascending=False))

    X, y = prepare_data(raw_df)
    if len(X) < 5:
        raise ValueError("At least 5 usable rows are recommended.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    candidates = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=250, random_state=42, n_jobs=-1
        ),
    }

    fitted_models = {}
    results = []
    for name, estimator in candidates.items():
        pipeline = build_pipeline(X_train, estimator)
        pipeline.fit(X_train, y_train)
        result = evaluate_model(name, pipeline, X_test, y_test)
        fitted_models[name] = pipeline
        results.append(result)

    results_df = pd.DataFrame([
        {key: value for key, value in result.items() if key != "predictions"}
        for result in results
    ]).sort_values("RMSE")

    print("\nModel comparison:\n", results_df.to_string(index=False))
    best_name = results_df.iloc[0]["model"]
    best_model = fitted_models[best_name]
    best_result = next(r for r in results if r["model"] == best_name)

    report = [
        "Sales Prediction - Model Evaluation",
        "====================================",
        f"Training rows: {len(X_train)}",
        f"Testing rows: {len(X_test)}",
        f"Best model by RMSE: {best_name}",
        "",
        results_df.to_string(index=False),
        "",
        "Interpretation: lower MAE, MSE and RMSE indicate smaller prediction errors.",
        "R2 closer to 1 generally indicates a better fit. Negative R2 is possible.",
        "Associations in observational data do not prove advertising caused sales changes.",
    ]
    (OUTPUT_DIR / "model_metrics.txt").write_text("\n".join(report), encoding="utf-8")

    plt.figure(figsize=(7, 6))
    sns.scatterplot(x=y_test, y=best_result["predictions"])
    low = min(float(y_test.min()), float(np.min(best_result["predictions"])))
    high = max(float(y_test.max()), float(np.max(best_result["predictions"])))
    plt.plot([low, high], [low, high], linestyle="--")
    plt.title(f"Actual vs Predicted Sales ({best_name})")
    plt.xlabel("Actual sales")
    plt.ylabel("Predicted sales")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "actual_vs_predicted.png", dpi=150)
    plt.close()

    plot_advertising_relationships(standardized)
    save_feature_importance(best_model, OUTPUT_DIR / "feature_importance.png")

    joblib.dump(best_model, MODEL_DIR / "sales_prediction_model.joblib")
    print(f"\nBest model: {best_name}")
    print("Saved model: models/sales_prediction_model.joblib")
    print("Saved metrics and charts in outputs/")


if __name__ == "__main__":
    main()
